# Jogo da Velha

Funcionalidades do roadmap para a próxima iteração:

- Detecção de fim de jogo (vitória do X, vitória do O ou empate)
- Marcador de pontuação (número de vitórias do X, número de vitórias do O e número de empates)
- Botão para reiniciar o jogo
- Botão para desfazer última jogada (não pode desfazer se jogo terminou)
- Temporizador (cada jogador tem 20 segundos para jogar, senão perde o jogo)
- Adicionar uma tela de boas vindas. A grade de jogo só aparece de a tela de boas vindas for clicada
